package Gun58.Ornek1;

public interface IFood {
    void taste();
    double ucret();
}
