package Gun43.JavaException;

public class _02_JavaRuntimeException {
    public static void main(String[] args) {

         System.out.println("Program Çalıştı...");
         String str="";

         str.charAt(3);
    }
}

// Çalışma zamanı hatası şeklinde bir hata grubu var  : RunTime Error, Exception
// Derlenme zamanı hatası şeklinde bir hata grubu var : Compile Error, Exception