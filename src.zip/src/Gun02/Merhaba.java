package Gun02;

public class Merhaba {
    public static void main(String[] args){
        System.out.println("Javaya Hoşgeldiniz");
        System.out.println("Merhaba dünya");
    }
}
