package Gun05;

public class Ornek5 {
    public static void main(String[] args) {
        // 68 rakamına karşılık gelen harfi, önce 68 rakamını bir int değere atayarak bulunuz

        int sayi=68;
        char harf = (char)sayi;

        System.out.println("harf = " + harf);
    }
}
