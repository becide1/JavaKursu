package Gun05;

public class Ornek4 {
    public static void main(String[] args) {
        // Kişinin ağırlığını double, boyunu in olarak değerler veriniz
        // ve bir satırda boyunuz ... ve kilonuz .. şeklinde yazdırınız.

        double kilo = 75.5;
        int boy = 180;

        String yazilacak = "boyunuz = "+boy+", kilonuz = "+ kilo;
        System.out.println(yazilacak);

    }
}
