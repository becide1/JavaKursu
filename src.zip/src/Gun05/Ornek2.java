package Gun05;

public class Ornek2 {
    public static void main(String[] args) {
        // 2 tane double ve short değişken tanımlayınız, değer atayınız
        // double değişkeni short değişkene çevirerek
        // bütün değerleri ekrana yazdırınız.

        double oran = 40000.4567;
        short ornekleme ;

        ornekleme = (short) oran;
        System.out.println("ornekleme = " + ornekleme);
    }
}
