package Gun62.p1;

public class Acc {
    int p;
    private int q;
    protected int r;
    public int s;
}
