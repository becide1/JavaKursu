package Gun60;

public class S23 {
    public static void main(String[] args) {
        int[] stack={10,20,30};
        int size=3;
        int idx= 0;
        /* line n1*/

        /********/
        do{
            idx++;
        }while(idx < size-1);
        /*******/


        System.out.print("The Top element: "+ stack[idx]);
        // Which code fragment, inserted at line n1, prints The Top element: 30?
    }
}
// The Top element: 30