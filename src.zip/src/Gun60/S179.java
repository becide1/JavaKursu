package Gun60;

public class S179 {
    public static void main(String[] args) {
        int numbers[]= {12,13,42,32,15,156,23,51,12};
        int[] keys = findMax(numbers);
    }

    // Dönen değer int dizisi  gelen değer de int dizisi olduğundan int[] değişkentipleri
    // yazıldı.
    static int[] findMax(int numbers[]){
            int[] keys= new int[3];
            /*code goes here*/
            return keys;
    }
}
