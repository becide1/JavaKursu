package Gun60;

public class S15 {
    public static void main(String[] args) {
        /* insert code here */
        int[] array;
        array= new int[2];
        /*..........*/

        array[0]= 10;
        array[1]=20;
        System.out.print(array[0]+":"+ array[1]);
    }
}
