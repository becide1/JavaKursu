package Gun08;

public class StringToLowerCase {
    public static void main(String[] args) {
        // ToLowerCase : stringi küçük harfe çevirir

        String text = "Merhaba Dünya";
        System.out.println("Orjinal hali    = " + text);
        System.out.println("küçük harf hali = " + text.toLowerCase());
    }
}
