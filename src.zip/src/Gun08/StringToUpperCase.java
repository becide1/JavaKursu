package Gun08;

public class StringToUpperCase {
    public static void main(String[] args) {
        // ToUpperCase : stringi büyük harfe çevirir

        String text="Merhaba Dünya";

        System.out.println("ojinal hali = " + text);
        System.out.println("büyük harf hali = " + text.toUpperCase());
    }
}
