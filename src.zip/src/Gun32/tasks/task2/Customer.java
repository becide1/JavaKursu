package Gun32.tasks.task2;

public class Customer {
    //fields
    String name;

    ElectricityAccount elektrikAbonesi;

}
