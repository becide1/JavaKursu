package Gun32.tasks.task1;

public class Rectangle {
    int width;
    int length;

    int getPerimeter()
    {
        return (width+length)*2;
    }

    int getArea()
    {
        return width*length;
    }

}
