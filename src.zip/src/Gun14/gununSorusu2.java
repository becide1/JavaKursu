package Gun14;

import java.util.Scanner;

public class gununSorusu2 {
    public static void main(String[] args) {
        // 2- Girilen 3 basamaklı bir sayıyı yazı ile yazdırınız

        Scanner oku = new Scanner(System.in);
        System.out.print("3 basamaklı sayı giriniz =");
        int sayi=oku.nextInt();

        int yuzlerBasamagi= sayi /100; // 3 basamaktan büyük olsaydı birde %10 almak gerekirdi
        int onlarBasamagi = (sayi/10)%10;
        int birlerBasamagi = sayi%10;

        switch (yuzlerBasamagi){
            case 1 : System.out.println("");break;
            case 2 : System.out.println("iki");break;
            case 3 : System.out.println("üç");break;
            case 4 : System.out.println("dört");break;
            case 5 : System.out.println("beş");break;
            case 6 : System.out.println("altı");break;
            case 7 : System.out.println("yedi");break;
            case 8 : System.out.println("sekiz");break;
            case 9 : System.out.println("dokuz");break;
        }
        System.out.println(" yüz");

        switch (onlarBasamagi){
            case 1 : System.out.println("on");break;
            case 2 : System.out.println("yirmi");break;
            case 3 : System.out.println("otuz");break;
            case 4 : System.out.println("kırk");break;
            case 5 : System.out.println("elli");break;
            case 6 : System.out.println("altmış");break;
            case 7 : System.out.println("yetmiş");break;
            case 8 : System.out.println("seksen");break;
            case 9 : System.out.println("doksan");break;
        }

        switch (birlerBasamagi){
            case 1 : System.out.println("bir");break;
            case 2 : System.out.println("iki");break;
            case 3 : System.out.println("üç");break;
            case 4 : System.out.println("dört");break;
            case 5 : System.out.println("beş");break;
            case 6 : System.out.println("altı");break;
            case 7 : System.out.println("yedi");break;
            case 8 : System.out.println("sekiz");break;
            case 9 : System.out.println("dokuz");break;
        }
    }
}
