package Gun14;

public class WhileLoop3 {
    public static void main(String[] args) {
        // ekrana 5 kez merhaba yazdırınız.

        int sayac=1;

        while(sayac <= 5){
            System.out.println(sayac+".kez Merhaba");
            sayac++;   // sayac=sayac+1;  sayac+=1
        }

    }
}
