package Gun04;

public class WideningCasting {
    public static void main(String[] args) {

//        byte -> short -> char -> int -> long -> float -> double ; otomatik dönüşüm

        int sayi = 9;
        double rakam = sayi;

        System.out.println("rakam = " + rakam);

    }
}
