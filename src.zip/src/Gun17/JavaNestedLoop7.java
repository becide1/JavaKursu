package Gun17;

public class JavaNestedLoop7 {
    public static void main(String[] args) {
        //TODO Write program that prints this using loops
        // *****
        // ****
        // ***
        // **
        // *


        for(int satir=5; satir >0 ; satir--)
        {
            for(int sutun=1; sutun <= satir ;sutun++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
