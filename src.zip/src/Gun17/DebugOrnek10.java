package Gun17;

public class DebugOrnek10 {
    public static void main(String[] args) {
        int x, y;
        // F8 adım adım ilerler, F9 ise breakpoint ten brekpoint e ilerler
        x = 10;
        y = x;

        x+=2;
        y--;

        y*=2;

        y=5;

    }
}
