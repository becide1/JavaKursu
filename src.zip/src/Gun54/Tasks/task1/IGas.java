package Gun54.Tasks.task1;

public interface IGas extends IVehicle {
    String changeOil();
}
