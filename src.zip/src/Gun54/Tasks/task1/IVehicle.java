package Gun54.Tasks.task1;

public interface IVehicle {
      String drive();
}
