package Gun54.Tasks.task1;

public interface IDiesel extends IVehicle{
    String changeDeisel();
}
