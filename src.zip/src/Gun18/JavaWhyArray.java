package Gun18;

public class JavaWhyArray {
    public static void main(String[] args) {
        // 1 sınıfta 100 tane öğrenci var, bunların final sonucunu okutunuz,
        // ortalamayı geçen öğrenci sayısını bulunuz.

//        int ogr1Final=0;
//        int ogr2Final=0;
//        int ogr3Final=0;
//        ...
//        ...
//        ... 100 tane ayrı değişken tanımlamam gerekiyor

//          int[] notlar=new int[100]; // hafızada 100 tane int değişken oluştur.
//          notlar[0]=> ilk değişkene ulaşmamı sağlıyor.
//          notlar[1]=> ikinci değişkene ulaşmamı sağlıyor.
//          ....
//          ....
//          ....
//          notlar[99]=> ilk değişkene ulaşmamı sağlıyor.

    }
}
