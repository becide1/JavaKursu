package Gun31.example.ex1;

public class Student {
    // fields
    String name;
    int grade;

    School schoolInfo; // başlatılmaış bir nesne adı henüz new olmadığından
    // Servis servisInfo;
    // Arakdas ArakdasInfo;

    // metodlar da eklenecek ilerki derslerde
}
