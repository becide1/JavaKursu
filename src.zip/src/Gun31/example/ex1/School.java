package Gun31.example.ex1;

public class School {
    // fields
    String name;
    String adress;
    String principalName;
    double tuitionFees;
}
