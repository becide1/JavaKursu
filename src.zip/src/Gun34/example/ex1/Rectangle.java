package Gun34.example.ex1;

// bir Rectangle sınıfı yazın, ve alanı vren getArea isimli bir metod ekleyin.
public class Rectangle {
    int length;
    int width;

    public int getArea()
    {
        return length*width;
    }
}
