package Gun09;

public class Sorular {
    public static void main(String[] args) {
      // Günün Soruları
      //  1- Girilen bir sayının birler basamağını ekrana yazdırınız.
      //  2- Girilen bir sayının onlar basamağını ekrana yazdırınız.
        // 3- Girilen bir sayının yüzler basamağını ekrana yazdırınız.
        // 4- Girilen 3 basamaklı bir sayınızn basamaklarının toplamını ekrana yazdırınız.
              // -> 435 -> 4,3,5  => 4+3+5 => 12
        // 5- Girilen 3 basamaklı bir sayının basamaklarına göre tersini bir sayı olarak
        // ekrana yazdırınız.Örneğin 435 -> 534 sayı olarak bulunacak.
        // 6- 2020 yılına kadar geçen gün sayısını bulunuz.
        // 7- Kullanıcıdan vize ve final notunu alınız. ort = 0.4 * vize + 0.6 * final olarak bulunuz.
    }
}
