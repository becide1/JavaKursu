package Gun09;

public class JavaArithmeticOperators2 {
    public static void main(String[] args) {
        int a=10;
        int b=5;

        System.out.println("çarpma işlemi");
        System.out.println(" a*b = " + (a*b) );

        System.out.println("Bölme işlemi");
        System.out.println(" a/b = " + (a/b));

        System.out.println("Modül işlemi");
        System.out.println(" a%b = " + (a%b)); // Modül, bölümünden kalan demek, bu işaretin yüzde ileilgisi yok
    }
}
