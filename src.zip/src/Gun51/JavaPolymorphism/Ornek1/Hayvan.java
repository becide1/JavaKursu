package Gun51.JavaPolymorphism.Ornek1;

public class Hayvan {
    private String name;

    public Hayvan(String name) {
        this.name = name;
    }

    public void ses()
    {
        System.out.println("ses çıkardı...");
    }
}
