package Gun51.finalAttribute2;

public class Tasit {
   public final String model;
   public final int kapiSayisi=4;

    public Tasit(String model) {
        this.model = model;
        // final tipi değişkenlere
        // ya ilk başta veya consructor da
        // değer atanabilir.
    }



}
