package Gun51.finalAttribute2;

public class Araba extends Tasit{

    public Araba(String model) {
        super(model);

        //super.model="opel";
        // final değişkene ilk değer
        // atandıktan sonra tekrar
        // değer atanamaz

    }

}
