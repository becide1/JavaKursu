package Gun51.finalMethod;

public class Arabalar {
    public static void main(String[] args) {
        Araba araba=new Araba("opel");
        System.out.println(araba);

    }
}
