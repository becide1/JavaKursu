package Gun51.finalClass;

//public class Araba extends Tasit {
//
//    public Araba(String model) {
//        super(model);
//    }
//}

// Final classlardan inheritance yapılamaz , main gibi
// noktalarda direk kullanılabilir.
