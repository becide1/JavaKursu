package Gun51.finalClass;

public class Arabalar {
    public static void main(String[] args) {
        Tasit tasit=new Tasit("opel");

        System.out.println(tasit);
    }
}
