package Gun51.finalAttribute;

public class Tasit {
    public final String model="Yeni Taşıt";

    public Tasit(String model) {
        //this.model = model;
        // final tipi olduğu için değiştirlemez
    }

}

// super class da final olarak tanılanmış
// değişken değeri değiştirilemez.
