package Gun51.finalAttribute;

public class Arabalar {
    public static void main(String[] args) {
        Araba araba=new Araba("opel");
       // araba.model = "opel";
       // final değişken olduğundan değiştirelemz
    }
}
