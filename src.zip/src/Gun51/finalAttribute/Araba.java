package Gun51.finalAttribute;

public class Araba extends Tasit {

    public Araba(String model) {
        super(model);

        //super.model="opel";
        // final olduğu için
        // değiştirelimiyor.
    }

}
