package Gun49.task2.pak1;

public class pak1Hayvan {
    public String ad;
    int yas; // hiç bir şey yazılmazsa default
    protected String cinsi;
    private String renk;
}
