package Gun49.task3;

public class A {
    public static String mesaj="A dan Merhaba";

}
