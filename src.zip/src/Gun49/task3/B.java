package Gun49.task3;

public class B extends A {

    public B()
    {
        super.mesaj = "B den Merhaba";
    }
}
