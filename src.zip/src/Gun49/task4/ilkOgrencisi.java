package Gun49.task4;

public class ilkOgrencisi extends Ogrenci {

    public ilkOgrencisi(String isim, String tipi) {
        super(sayacID++, isim, tipi);
    }
}
