package Gun33.Tasks.task1;

public class myMath {

    public static int getMin(int value1,int value2){
        return Math.min(value1,value2);
    }

    public static int getMax(int value1,int value2){
        return Math.max(value1,value2);
    }

    public static int getMutlak(int value1){
        return Math.abs(value1);
    }

    public static double getUs(int value1,int value2){

        return Math.pow(value1,value2);
    }

    public static double getKarekok(int value1){
        return Math.sqrt(value1);
    }

}
