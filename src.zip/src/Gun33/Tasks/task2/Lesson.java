package Gun33.Tasks.task2;

public class Lesson {
    String name;
    int credit;



}
