package Gun16;

public class JavaForLoop1 {
    public static void main(String[] args) {

        // While Loop
        int i=0;
        while (i < 5){
            System.out.println("w_i = " + i);
            i++;
        }

        for(i=0;i<5;i++){
            System.out.println("f_i = " + i);
        }

    }
}
