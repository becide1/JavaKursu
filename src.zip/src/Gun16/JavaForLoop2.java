package Gun16;

public class JavaForLoop2 {
    public static void main(String[] args) {
        // 0 den 10(dahil) kadar sayıları ekrana yazdırınız.
        // 10 dan 0(dahil) kadar sayıları ekrana yazdırınız.

        for(int i=0; i<=10; i++)
        {
            System.out.println("i_i = " + i);
        }

        for(int i=10; i>=0 ;i--)
        {
            System.out.println("g_i = " + i);
        }
    }
}
