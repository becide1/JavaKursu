package Gun12;

public class JavaMath5 {
    public static void main(String[] args) {
        int a=-12;
        int b=2;

        System.out.println("a nın mutlak degeri = " + Math.abs(a)); // 12
        System.out.println("-2,4 sayıdan büyük olanı = " + Math.max(-2,4)); // 4
        System.out.println("-2,4 sayıdan küçük olanı = " + Math.min(-2,4)); // -2
        System.out.println( "16 nın karekökü : " + Math.sqrt(16) ); // 4
        System.out.println( "2 nin 3.kuvveti: " + Math.pow( 2, 3 ) ); // 8
        System.out.println( "round of 3.1: " + Math.round( 3.1 ) ); // 3
        System.out.println( "round of 3.5: " + Math.round( 3.5 ) ); // 4
        System.out.println( "ceil of 3.1: " + Math.ceil( 3.1 ) ); // 4
        System.out.println( "ceil of 3.5: " + Math.ceil( 3.5 ) ); // 4
        System.out.println( "floor of 3.1: " + Math.floor( 3.1 ) ); // 3
        System.out.println( "floor of 3.5: " + Math.floor( 3.5 ) ); // 3


    }
}
