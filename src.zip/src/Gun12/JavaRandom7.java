package Gun12;

public class JavaRandom7 {
    public static void main(String[] args) {
        // Soru : 0 ile 6 arasında random sayı üreten programı yazınız.

        int sayi = (int)(Math.random()*6 +1) ;
        System.out.println("sayi = " + sayi);


    }
}
