package Gun55.Ornekler.Ornek3;

public abstract class Salad extends Food{
    @Override
    public void taste() {
        System.out.println("sirkeli, limonlu, sumaklı");
    }
}
