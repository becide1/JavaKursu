package Gun55.Ornekler.Ornek3;

public class YemekDunyasiMain {
    public static void main(String[] args) {
        Baklava baklava=new Baklava();
        baklava.madeIn();
        baklava.taste();


    }
}
