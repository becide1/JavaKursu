package Gun55.Ornekler.Ornek3;

public abstract class Sweet extends Food {
    @Override
    public void taste() {
        System.out.println("tatlı, iyi, şekerli");
    }
}
