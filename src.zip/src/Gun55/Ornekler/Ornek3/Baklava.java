package Gun55.Ornekler.Ornek3;

public class Baklava extends Sweet{
    @Override
    public void madeIn() {
        System.out.println("Bu baklava Türkiye ye aittir");
    }
}
