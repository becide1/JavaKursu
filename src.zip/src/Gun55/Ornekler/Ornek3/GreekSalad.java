package Gun55.Ornekler.Ornek3;

public class GreekSalad extends Salad{

    @Override
    public void madeIn() {
        System.out.println("Yunanistan");
    }
}
