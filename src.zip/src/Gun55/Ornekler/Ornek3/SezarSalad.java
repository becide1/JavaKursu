package Gun55.Ornekler.Ornek3;

public class SezarSalad extends Salad {
    @Override
    public void madeIn() {
        System.out.println("italya");
    }
}
