package Gun53.Tasks.task1;

public class Kare extends Dikdortgen{
   
}
