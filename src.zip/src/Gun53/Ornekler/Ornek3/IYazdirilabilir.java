package Gun53.Ornekler.Ornek3;

public interface IYazdirilabilir {
    void yaz();
}
