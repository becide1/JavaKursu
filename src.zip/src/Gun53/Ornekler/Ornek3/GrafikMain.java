package Gun53.Ornekler.Ornek3;

public class GrafikMain {
    public static void main(String[] args) {
         A4 nesne=new A4();
         nesne.yaz();
         nesne.goster();
    }
}
