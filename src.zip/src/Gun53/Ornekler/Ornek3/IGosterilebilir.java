package Gun53.Ornekler.Ornek3;

public interface IGosterilebilir {
    void goster();
}
