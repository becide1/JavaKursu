package Gun53.Ornekler.Ornek2;

public class Cember implements ICizilebilir {
    @Override
    public void ciz() {
        System.out.println("Çember çizildi...");
    }
}
