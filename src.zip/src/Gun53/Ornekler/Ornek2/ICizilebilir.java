package Gun53.Ornekler.Ornek2;

public interface ICizilebilir {
    void ciz();

      // gövdeli metodlar kullanılamıyor.
//    void ciz(){
//
//    }
}
