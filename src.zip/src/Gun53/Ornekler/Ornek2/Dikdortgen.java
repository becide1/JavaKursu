package Gun53.Ornekler.Ornek2;

public class Dikdortgen implements ICizilebilir{
    @Override
    public void ciz() {
        System.out.println("Dikdörtgen çizildi...");
    }
}
