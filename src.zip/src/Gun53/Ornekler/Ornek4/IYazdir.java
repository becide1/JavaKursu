package Gun53.Ornekler.Ornek4;

public interface IYazdir {
    void yaz();
}
