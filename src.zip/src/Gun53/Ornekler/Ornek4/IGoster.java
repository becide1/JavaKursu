package Gun53.Ornekler.Ornek4;

public interface IGoster {
    void goster();
    void yaz();
}
