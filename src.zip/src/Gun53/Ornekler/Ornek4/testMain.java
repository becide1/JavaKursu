package Gun53.Ornekler.Ornek4;

public class testMain {
    public static void main(String[] args) {
        Test test=new Test();
        test.yaz();

        //
    }
}
