package Gun53.Ornekler.Ornek1;

public class yazdirMain {
    public static void main(String[] args) {
        A6 nesne=new A6();
        nesne.yaz();
    }
}
