package Gun53.Ornekler.Ornek1;

public class A6 implements IYazdirilabilir {

    @Override
    public void yaz() {
        System.out.println("yadırma işlemi yapıldı...");
    }
}
