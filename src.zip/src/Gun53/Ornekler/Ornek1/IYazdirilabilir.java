package Gun53.Ornekler.Ornek1;

public interface IYazdirilabilir {
    void yaz();
}
