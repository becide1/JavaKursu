package Gun10;

public class GununSorusu2 {
    public static void main(String[] args) {
       // 2020 yılına kadar geçen gün sayısını bulunuz.

       int gecenGunMiktari = (2020 * 365) +  (2020/4);
        System.out.println("gecenGunMiktari = " + gecenGunMiktari);
    }
}
