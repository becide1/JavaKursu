package Gun03;

public class JavaDataTypes {
    public static void main(String[] args) {

        byte byteDeger=4;
        short shortDeger=3000;
        int intDeger=200000;
        long longDeger=1234599999;

        float floatDeger=3.14f;
        double doubleDeger = 3.14;

        char charDeger1 ='A';
        char charDeger2 = 65;

        boolean boolDeger1 = true;
        boolean boolDeger2 = false;

        System.out.println("byteDeger = " + byteDeger);
        System.out.println("shortDeger = " + shortDeger);
        System.out.println("intDeger = " + intDeger);
        System.out.println("longDeger = " + longDeger);
        System.out.println("floatDeger = " + floatDeger);
        System.out.println("doubleDeger = " + doubleDeger);
        System.out.println("charDeger1 = " + charDeger1);
        System.out.println("charDeger2 = " + charDeger2);
        System.out.println("boolDeger1 = " + boolDeger1);
        System.out.println("boolDeger2 = " + boolDeger2);
    }
}
