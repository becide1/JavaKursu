package Gun03;

public class Ornek1 {
    public static void main(String[] args) {
        // Pazartesi kelimesini her harfini ayrı bir satıra gelecek şekile yazdırınız.

        System.out.println("P\na\nz\na\nr\nt\ne\ns\ni");

        System.out.println();
        System.out.println("p");
        System.out.println("a");
        System.out.println("z");

    }
}
