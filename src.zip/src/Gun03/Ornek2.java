package Gun03;

public class Ornek2 {
    public static void main(String[] args) {
        //2 kenarı için değer verdiğiniz, bir
        //dikdörtgenin çevresini bularak yazdırınız.

        int b=15;
        int k=10;

        int cevre = b + b + k + k;

        System.out.println("cevre = " + cevre);

    }
}
