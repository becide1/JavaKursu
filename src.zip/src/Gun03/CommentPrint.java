package Gun03;

public class CommentPrint {
    public static void main(String[] args){
        //bu benim ilk programım : yorum haline getirildi

        /*
        bu
                benim         :  bu da çoklu yorum satırı
                ilk
                        programım */

        System.out.println("Javaya Hoşgeldiniz");
        System.out.println("Merhaba dünya");
    }
}
