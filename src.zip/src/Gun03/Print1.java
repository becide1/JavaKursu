package Gun03;

public class Print1 {
    // Haftanın üç günün yan yana ve alt alta yazdırınız
    public static void main(String[] args) {

        System.out.print("Pazartesi ");
        System.out.print("Salı ");
        System.out.println("Çarşamba");

        System.out.println("*********");

        System.out.println("Pazartesi");
        System.out.println("Salı");
        System.out.println("Çarşamba");
    }
}
