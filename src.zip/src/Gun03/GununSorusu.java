package Gun03;

public class GununSorusu {
    public static void main(String[] args) {
        //       Soru :   Ekrana      "Hello ", "World  \ /"        şeklinde yazınız

        System.out.println("   \"Hello \" , \"World \\ / \"    ");

    }
}
