package Gun03;

public class JavaVaribles {
    public static void main(String[] args) {

        int sayi=5;  // 1.yöntem

        int sayi2;  // 2.yöntem
        sayi2=10;

        int sayi3, sayi4, sayi5; // 3.yöntem

        int sayi6=6, sayi7 = 9;   // 4.yöntem

        int a=10;
        int b= 20;
        int toplam= a+b;
        toplam = toplam +2;

        System.out.println("toplam = " + toplam);

    }
}
