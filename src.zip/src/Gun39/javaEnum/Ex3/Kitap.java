package Gun39.javaEnum.Ex3;

public class Kitap {
    String name;
    KitapKategori kategori;
}
