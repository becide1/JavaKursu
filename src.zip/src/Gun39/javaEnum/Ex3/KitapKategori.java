package Gun39.javaEnum.Ex3;

public enum KitapKategori {
    KLASIK,
    ROMAN,
    FANTEZI,
    TARIH,
    EKONOMI
}
