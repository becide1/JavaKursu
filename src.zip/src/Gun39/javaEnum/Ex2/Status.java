package Gun39.javaEnum.Ex2;

public enum Status {
  ACTIVE, LOGGED_IN, INACTIVE
}
