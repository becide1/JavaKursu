package Gun39.javaEnum.Ex2;

public class User {
    String name;
//    int Role=0; // 1Admin,2custome
//    int Status=0; // 1 active, 2 Loginin, 3 inactive

    Role yetkisi;
    Status durum;

}
