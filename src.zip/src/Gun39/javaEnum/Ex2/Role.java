package Gun39.javaEnum.Ex2;

public enum Role {
   ADMIN, CUSTOMER
}
