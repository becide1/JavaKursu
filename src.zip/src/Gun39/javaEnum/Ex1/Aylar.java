package Gun39.javaEnum.Ex1;

public enum Aylar {
    OCAK,
    SUBAT,
    MART,
    NISAN,
    MAYIS,
    HAZIRAN,
    TEMMUZ,
    AGUSTOS,
    EYLUL,
    EKIM,
    KASIM,
    ARALIK
}
