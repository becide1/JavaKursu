package Gun48.Extends1;

public class Personel {
    String ad;
    String soyad;
    int yas;
    double maas;
    String departman;
    int sicilNo;

    public double getMaas()
    {
        return this.maas;
    }

}
