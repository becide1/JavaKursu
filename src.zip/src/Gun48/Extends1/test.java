package Gun48.Extends1;

public class test {
    public static void main(String[] args) {

        int no=2;

        Object sayi=2;
        Object ad="ismet";


    }
}
