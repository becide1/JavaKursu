package Gun48.Extends1;

public class Yonetici {
//    String ad;
//    String soyad;
//    int yas;
//    double maas;
//    String departman;
//    int sicilNo;
//    int bagliPersonelSayisi;
//    double gorevTazminati;
//
//    public double getMaas()
//    {
//        return this.maas;
//    }
//
//    public void zamYap(int yuzde)
//    {
//        System.out.println(yuzde + " personele zam yapıldı.");
//    }

}
