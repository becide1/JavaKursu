package Gun22;

public class JavaMethods1 {

    public static void main(String[] args) {
        System.out.println("Merhaba Dünya"); // Ekrana yazı işlemini yapar
        System.out.println("Merhaba Dünya 2"); //

        merhabaDunyaYaz(); // fonksiyonu çağırma
    }
    // metod veya fonksiyon tanımlama
    public static void merhabaDunyaYaz()
    {
        System.out.println("Merhaba Dünya 3");
    }


}
