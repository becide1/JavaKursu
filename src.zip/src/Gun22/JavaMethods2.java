package Gun22;

public class JavaMethods2 {
    public static void main(String[] args) {
      merhabaYaz();

      //System.out.println("ismet");
      ismeMerhabaYaz("ismet");
      ismeMerhabaYaz("Ayşe");
    }

    public static void merhabaYaz()
    {
        System.out.println("Merhaba ");
    }
                      //ismeMerhabaYaz("ismet");
    public static void ismeMerhabaYaz(String isim)
    {
        System.out.println("Merhaba "+isim);
    }
}
