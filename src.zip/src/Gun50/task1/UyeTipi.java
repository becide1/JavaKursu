package Gun50.task1;

public enum UyeTipi {
    OGRENCI, CALISAN
}
