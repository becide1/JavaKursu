package Gun50.task2;

public class Soru2 {
    public static void main(String[] args) {

        try {
            System.out.println("LINE A");
            System.out.println("LINE B");
            System.out.println("LINE C");
            System.out.println("LINE D");
        } catch (Exception e) {
            System.out.println("LINE E");
            System.out.println("LINE F");
        }
        System.out.println("LINE G");
    }

}


//      for(int i=1; i<=100;i++)
//           System.out.println(i);     1 2 3 4 5 6
//
//              System.out.println(100-i);   99 98 97 96 95 ....