package Gun37.instanceModifiers.publicModifier.same;

public class SearchEngine {
    public String name;

    public SearchEngine(String name) {
        this.name = name;
    }

    public String toString() {
        return "SearchEngine{" +
                "name='" + name + '\'' +
                '}';
    }
}
