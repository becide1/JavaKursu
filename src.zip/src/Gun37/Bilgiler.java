package Gun37;

public class Bilgiler {
    // Erişim alanları :
    // 1- Class ın için
    // 2- Paketin için
    // 3- Projenin içi (yani diğer paketler)

    // Public : Projenin her tarafından erişilebilir, yani diğer paketlerden bile. (Class, field, metodlarda, constructor)
    // default: Yani hiç bir şey yazılmazsa, yani diğer adı friendly : sadece paketin içindekiler erişebilir. (Class, field, metodlarda, constructor)
    // private: Sadece içinde bulunduğu sınıf tan erişilebilir.(field, metodlarda)

    // protected aynı default gibi çalışır, bir farkı var onu Inheritance (kalıtım) konusunda göreceğiz.

}
