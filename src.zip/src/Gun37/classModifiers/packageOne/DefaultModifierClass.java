package Gun37.classModifiers.packageOne;

//Default yani hiçbirşey yazılmadığında
//Sadece kendi paketinin içinden erişilebilir
class DefaultModifierClass {

}
