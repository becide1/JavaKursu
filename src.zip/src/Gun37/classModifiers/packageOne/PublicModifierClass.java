package Gun37.classModifiers.packageOne;

// Public: diğer paketlerden de erişilebilir.
// yani her taraftan erişilebilir.
public class PublicModifierClass {

}
