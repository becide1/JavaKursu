package Gun37.classModifiers.packageOne;

public class SamePackageClass {
    public static void main(String[] args) {
       DefaultModifierClass sm1=new DefaultModifierClass();
       PublicModifierClass sm2=new PublicModifierClass();
    }
}
