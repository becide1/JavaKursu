package Gun38.nonAccessModifier.finalModifier.example;

public class Constants {
    static final double pi=3.14;

    static final int hourInDay = 24;
    static final int minuteInHour = 60;
    static final int secondInMinute = 60;
}
